// Main Program
public class Main {
    public static void main(String[] args) {
        Fabric kain = new Fabric("Katun", 50000, 1.0);
        Transaction trx = new Transaction(kain, 15);
        trx.processTransaction();

        Utility.printReceipt("Salmiah");

        ExceptionDemo.divide(10, 0);

        Inventory inv = new Inventory();
        inv.addProduct(kain);
        inv.addProduct(new Accessory("Benang", 10000));
        inv.showProducts();

    
        FabricDB db = new FabricDB();
        db.create();
        db.read();
        db.update();
        db.delete();
    }
}