// b. Interface & Implementasi
interface CRUDOperations {
    void create();
    void read();
    void update();
    void delete();
}

class DatabaseHandler implements CRUDOperations {
    @Override
    public void create() { System.out.println("Insert data to DB"); }
    @Override
    public void read() { System.out.println("Read data from DB"); }
    @Override
    public void update() { System.out.println("Update data in DB"); }
    @Override
    public void delete() { System.out.println("Delete data from DB"); }
}